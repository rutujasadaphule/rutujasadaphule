from website import create_app
from keras.models import load_model
from flask import Flask , render_template , request, jsonify
import processor

app = create_app()

model = load_model("fitness_model.h5")

#app = create_app()



@app.route('/mail', methods=["GET", "POST"])
def mail():
    return render_template('contact.php') 

@app.route('/bot', methods=["GET", "POST"])
def index():
        return render_template('index.html', **locals())



@app.route('/chatbot', methods=["GET", "POST"])
def chatbotResponse():

        if request.method == 'POST':
                    the_question = request.form['question']
                    response = processor.chatbot_response(the_question)

        return jsonify({"response": response })


@app.route("/Result" , methods = ["GET" ] )
def prediction():
        p1 = request.args.get( "x" )
        p2 = request.args.get( "y" )
        p3 = request.args.get( "z1" )
        if p3 == "M":
            r = 0
        else:
            r = 1
        p4 = request.args.get( "z2" )
        p5 = request.args.get( "z3" )
        p6 = request.args.get( "z4" )
        p7 = request.args.get( "z5" ) 
        p8 = request.args.get( "z6" ) 
        p9 = request.args.get( "z7" ) 


        output = model.predict([[ int(p9) , int(p6) , int(p7) , float(p4) , float(p5) , int(p8), int(r)]])
        


        ans = str(round(output[0][0] ))
        if int(ans) == 0:
                return render_template( "unfit.html")

        else :
                return render_template( "fit.html")

if __name__ == '__main__':
    app.run(debug=True, host="172.17.0.2" , port=2222)
