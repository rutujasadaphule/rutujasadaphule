from flask import Blueprint, render_template, request, flash, jsonify
from flask_login import login_required, current_user
from .models import Note
from . import db
import json

views = Blueprint('views', __name__)




@views.route('/form', methods=['GET', 'POST'])
@login_required
def form():
	return render_template("form.html", user=current_user)


@views.route('/' , methods=['GET', 'POST'])
def home():
        return render_template("home.html")


@views.route('/about' , methods=['GET', 'POST'])
def about():
        return render_template("about-us.html")

@views.route('/bmi' , methods=['GET', 'POST'])
def bmi():
        return render_template("bmi.html")

@views.route('/faq' , methods=['GET', 'POST'])
def faq():
        return render_template("faq.html")

@views.route('/contact' , methods=['GET', 'POST'])
def contact():
        return render_template("contact.html")

@views.route('/unfit' , methods=['GET', 'POST'])
def unfit():
        return render_template("unfit.html")

@views.route('/unfit01' , methods=['GET', 'POST'])
def unfit01():
        return render_template("unfit01.html")

@views.route('/fit' , methods=['GET', 'POST'])
def fit():
        return render_template("fit.html")



