from . import db
from flask_login import UserMixin
from sqlalchemy.sql import func


class Note(db.Model):
	id = db.Column(db.Integer, primary_key=True)
	data = db.Column(db.String(10000))
	date = db.Column(db.DateTime(timezone=True), default = func.now())
	user_id = db.Column(db.Integer, db.ForeignKey('user.id'))


class User(db.Model, UserMixin):
	id = db.Column(db.Integer, primary_key=True)
	email = db.Column(db.String(150), unique=True)
	full_name = db.Column(db.String(150))
	password = db.Column(db.String(150))
	notes = db.relationship('Note')


'''
class Form(db.Model):
	username = db.Column(db.String(1000), primary_key=True)
	age = db.Column(db.Integer)
	height = db.Column(db.Integer)
	weight = db.Column(db.Integer)
'''