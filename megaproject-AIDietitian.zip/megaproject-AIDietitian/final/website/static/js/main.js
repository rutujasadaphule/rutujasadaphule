

'use strict';

(function ($) {

    /*------------------
        Preloader
    --------------------*/
    $(window).on('load', function () {
        $(".loader").fadeOut();
        $("#preloder").delay(200).fadeOut("slow");
    });

    /*------------------
        Background Set
    --------------------*/
    $('.set-bg').each(function () {
        var bg = $(this).data('setbg');
        $(this).css('background-image', 'url(' + bg + ')');
    });

    //Canvas Menu
    $(".canvas__open").on('click', function () {
        $(".offcanvas-menu").addClass("show-offcanvas-menu");
        $(".offcanvas-menu-overlay").addClass("active");
        $("body").addClass("over-hid");
    });

    $(".offcanvas-menu-overlay").on('click', function () {
        $(".offcanvas-menu").removeClass("show-offcanvas-menu");
        $(".offcanvas-menu-overlay").removeClass("active");
        $("body").removeClass("over-hid");
    });

    /*------------------
		Navigation
	--------------------*/
    $(".mobile-menu").slicknav({
        prependTo: '#mobile-menu-wrap',
        allowParentLinks: true
    });

    /*------------------
        Hero Slider
    --------------------*/
    var hero_s = $(".hero__sliders");
    hero_s.owlCarousel({
        loop: true,
        margin: 0,
        items: 1,
        dots: false,
        nav: true,
        navText: ["<span class='arrow_left'><span/>", "<span class='arrow_right'><span/>"],
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        smartSpeed: 1200,
        autoHeight: false,
        autoplay: true
    });

    /*--------------------------
    Testimonial Slider
    ----------------------------*/
    var testimonialSlider = $(".testimonial__slider");
    testimonialSlider.owlCarousel({
        loop: true,
        margin: 0,
        items: 1,
        dots: true,
        smartSpeed: 1200,
        autoHeight: false,
        autoplay: false
    });

    /*-----------------------------
        Team Slider
    -------------------------------*/
    $(".team__slider").owlCarousel({
        loop: true,
        margin: 0,
        items: 2,
        dots: false,
        nav: true,
        navText: ["<span class='arrow_left'><span/>", "<span class='arrow_right'><span/>"],
        smartSpeed: 1200,
        autoHeight: false,
        autoplay: true,
        responsive: {

            320: {
                items: 1
            },
            768: {
                items: 2
            }
        }
    });

    /*--------------------------
        Select
    ----------------------------*/
    $(".class-select").niceSelect();
    $("select").niceSelect();

    /*------------------
        Accordin Active
    --------------------*/
    $('.collapse').on('shown.bs.collapse', function () {
        $(this).prev().addClass('active');
    });

    $('.collapse').on('hidden.bs.collapse', function () {
        $(this).prev().removeClass('active');
    });

    /*------------------
		Pricing
    --------------------*/
    $(".pricing__item").mouseover(function () {
        $(".pricing__item").removeClass('active');
        $(this).addClass('active');
    });

    /*------------------
		Barfiller
	--------------------*/
    $('#bar1').barfiller({
        barColor: "#5768AD",
    });

    $('#bar2').barfiller({
        barColor: "#5768AD",
    });

    $('#bar3').barfiller({
        barColor: "#5768AD",
    });

    $('#bar4').barfiller({
        barColor: "#5768AD",
    });

    /*------------------
        Counter Up
    --------------------*/
    $('.choose-counter').each(function () {
        $(this).prop('Counter', 0).animate({
            Counter: $(this).text()
        }, {
            duration: 4000,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now));
            }
        });
    });

})(jQuery);


var $=function( id ){return document.getElementById(id);};
function msystem(){if( $('msw').value=='metric'){ $('thw').innerHTML=' (Cms)';}else{ $('thw').innerHTML=' (inches)';};if( $('msm').value=='metric'){ $('thm').innerHTML=' (Cms)'; $('twm').innerHTML=' (Kgs)';}else{ $('thm').innerHTML=' (inches)'; $('twm').innerHTML=' (lbs)';};if( $('msf').value=='metric'){ $('thf').innerHTML=' (Cms)'; $('tneck').innerHTML=' (Cms)'; $('twaist').innerHTML=' (Cms)'; $('thips').innerHTML=' (Cms)';}else{ $('thf').innerHTML=' (inches)'; $('tneck').innerHTML=' (inches)'; $('twaist').innerHTML=' (inches)'; $('thips').innerHTML=' (inches)';}}
function bmass (){var ms= $('msm').value;var height= $('hm').value;var weight= $('wm').value;if(height==null || height.length==0 || weight==null || weight.length==0 ){ $('bmi').value='Pl. enter data.';}else{ $('bmi').value='';}if(ms=='metric'&&height>0){ $('bmi').value=Math.round(weight/(height*height/10000)*100)/100+' kg/m2 ' }else if(ms=='us'&&height>0){ $('bmi').value=Math.round(703*weight/(height*height)*100)/100+' kg/m2 ' }}
