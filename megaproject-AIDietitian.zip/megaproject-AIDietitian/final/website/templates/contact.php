<?php
    if(isset($_POST['submit']))
    {
    $name=$_POST['name'];
    $email=$_POST['email'];
    $message=$_POST['message'];

    $to='aidietitian01@gmail.com';
    $subject="New message from user";
    $message="Hello AIDietitian,\n You have received mail from ". $name."\n".
                 "User Email:" .$email."\n".
                 "User Message:". $message."\n";

    $headers="From: $email \n";
        if(mail($to,$subject,$message,$headers))
        {

            header("location:return.html");
        }
        else
        {
	     header("location:/");
        }           
    }
?>
